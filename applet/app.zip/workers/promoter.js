worker.onMessage(function (res) {
  console.log(res)
  // for (let i = 1; i < 10; i--) {
  //   console.log(i);
  // }
  // setInterval(() => {
  //   console.count('定时器1：');
  // }, 2000);
  // setInterval(() => {
  //   console.count('定时器2：');
  // }, 2000)
  // setInterval(() => {
  //   console.count('定时器3：');
  // }, 2000);
  // setInterval(() => {
  //   console.count('定时器4：');
  // }, 2000)
  // setInterval(() => {
  //   console.count('定时器5：');
  // }, 2000);
  // setInterval(() => {
  //   console.count('定时器6：');
  // }, 2000)
  // setInterval(() => {
  //   console.count('定时器7：');
  // }, 2000);
  // setInterval(() => {
  //   console.count('定时器8：');
  // }, 2000)
})
