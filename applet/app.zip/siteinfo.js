module.exports = {
  siteroot: 'https://dev2.91bd.cn/index.php'
  // siteroot: 'http://localhost:8080/index.php'
};
