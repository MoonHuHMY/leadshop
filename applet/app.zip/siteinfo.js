module.exports = {
    "uniacid": "4",
    "acid": "3",
    "multiid": "0",
    "version": "1.2.0",
    "AppURL": "http://www.qmpaas.com/index.php",
    // "siteroot": "http://www.qmpaas.com/index.php",
    "siteroot": "https://dev.91bd.cn/index.php",
    // "siteroot": "https://test.leadshop.vip/index.php",
    "design_method": "3"
}