module.exports = {
    "uniacid": "4",
    "acid": "3",
    "multiid": "0",
    "version": "1.1.5",
    "AppURL": "http://www.qmpaas.com/index.php",
    "siteroot": "http://www.qmpaas.com/index.php",
    "design_method": "3"
}