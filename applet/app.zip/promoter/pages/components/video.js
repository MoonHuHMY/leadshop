(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["promoter/pages/components/video"],{2288:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var i={name:"video",props:{src:{type:String,required:!0},poster:{type:String},value:{type:[Number,null]},index:{type:Number}},data:function(){return{isPlay:!1}},methods:{playVideo:function(){this.isPlay=!this.isPlay,this.isPlay?this.$emit("input",this.index):this.$emit("input",null)}},watch:{value:{handler:function(t){t!==this.index&&(this.isPlay=!1)}}}};e.default=i},"2cf3":function(t,e,n){"use strict";n.r(e);var i=n("2288"),u=n.n(i);for(var r in i)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(r);e["default"]=u.a},4376:function(t,e,n){"use strict";n.r(e);var i=n("b42e"),u=n("2cf3");for(var r in u)["default"].indexOf(r)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(r);n("43e7");var a,o=n("522a"),s=Object(o["a"])(u["default"],i["b"],i["c"],!1,null,"490b6314",null,!1,i["a"],a);e["default"]=s.exports},"43e7":function(t,e,n){"use strict";var i=n("bf51"),u=n.n(i);u.a},b42e:function(t,e,n){"use strict";var i;n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return r})),n.d(e,"a",(function(){return i}));var u=function(){var t=this,e=t.$createElement;t._self._c},r=[]},bf51:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'promoter/pages/components/video-create-component',
    {
        'promoter/pages/components/video-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("4376"))
        })
    },
    [['promoter/pages/components/video-create-component']]
]);
