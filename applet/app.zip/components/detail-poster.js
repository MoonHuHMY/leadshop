(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/detail-poster"],{"47c8":function(t,e,n){"use strict";var i;n.d(e,"b",(function(){return c})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return i}));var c=function(){var t=this,e=t.$createElement;t._self._c},u=[]},"4f67":function(t,e,n){"use strict";n.r(e);var i=n("732a"),c=n.n(i);for(var u in i)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(u);e["default"]=c.a},"732a":function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={name:"detail-poster",props:{goods:Object},data:function(){return{width:562,height:784,widthIn:300,heightIn:500,context:null}},mounted:function(){setTimeout((function(){var e=t.createCanvasContext("graceCanvas");e.setFillStyle("red"),e.fillRect(0,0,1500,2e3),e.setFillStyle("blue"),e.fillRect(150,0,150,200),e.clearRect(10,10,150,75),e.draw()}),2e3)},methods:{initSize:function(){this.widthIn=t.upx2px(this.width),this.heightIn=t.upx2px(this.height)},draw:function(){this.step01()},step01:function(){this.context.setFillStyle("#F1F3F5"),this.context.fillRect(0,0,this.widthIn,this.heightIn),this.context.drawImage(this.goods.slideshow[0],0,0,this.widthIn,this.heightIn)}}};e.default=n}).call(this,n("543d")["default"])},"95cc":function(t,e,n){"use strict";n.r(e);var i=n("47c8"),c=n("4f67");for(var u in c)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return c[t]}))}(u);var a,o=n("f0c5"),s=Object(o["a"])(c["default"],i["b"],i["c"],!1,null,"1f4584cc",null,!1,i["a"],a);e["default"]=s.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/detail-poster-create-component',
    {
        'components/detail-poster-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("95cc"))
        })
    },
    [['components/detail-poster-create-component']]
]);
