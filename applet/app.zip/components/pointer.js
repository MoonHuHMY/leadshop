(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/pointer"],{"639e":function(t,e,n){"use strict";n.r(e);var r=n("edfe"),u=n("85f9");for(var o in u)["default"].indexOf(o)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(o);n("77b7");var a,f=n("8261"),i=Object(f["a"])(u["default"],r["b"],r["c"],!1,null,"6f1dbd6d",null,!1,r["a"],a);e["default"]=i.exports},"77b7":function(t,e,n){"use strict";var r=n("9ab3"),u=n.n(r);u.a},"85f9":function(t,e,n){"use strict";n.r(e);var r=n("cf88"),u=n.n(r);for(var o in r)["default"].indexOf(o)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(o);e["default"]=u.a},"9ab3":function(t,e,n){},cf88:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={props:{current:{type:[String,Number,Boolean],default:1},number:{type:[String,Number,Boolean],default:""},margin:{type:[Number],default:8},type:{type:[String,Number,Boolean],default:1},align:{type:[String,Number,Boolean],default:"left"},color:{type:[String,Number,Boolean],default:"#f44"}},methods:{activeColor:function(t){return this.current==t?this.color:"rgba(0,0,0,.3)"}}};e.default=r},edfe:function(t,e,n){"use strict";var r;n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return o})),n.d(e,"a",(function(){return r}));var u=function(){var t=this,e=t.$createElement,n=(t._self._c,t.type<3?t.__map(t.number,(function(e,n){var r=t.__get_orig(e),u=t.activeColor(n);return{$orig:r,m0:u}})):null);t.$mp.data=Object.assign({},{$root:{l0:n}})},o=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/pointer-create-component',
    {
        'components/pointer-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('934e')['createComponent'](__webpack_require__("639e"))
        })
    },
    [['components/pointer-create-component']]
]);
