(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/he-no-content-yet"],{"938c":function(t,n,e){},aa66:function(t,n,e){"use strict";e.r(n);var u=e("e236"),r=e("e1cb");for(var a in r)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(a);e("f0b1");var c,i=e("f0c5"),f=Object(i["a"])(r["default"],u["b"],u["c"],!1,null,"3543f762",null,!1,u["a"],c);n["default"]=f.exports},e1cb:function(t,n,e){"use strict";e.r(n);var u=e("f514"),r=e.n(u);for(var a in u)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(a);n["default"]=r.a},e236:function(t,n,e){"use strict";var u;e.d(n,"b",(function(){return r})),e.d(n,"c",(function(){return a})),e.d(n,"a",(function(){return u}));var r=function(){var t=this,n=t.$createElement;t._self._c},a=[]},f0b1:function(t,n,e){"use strict";var u=e("938c"),r=e.n(u);r.a},f514:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={name:"he-no-content-yet",props:{text:{type:String,default:function(){return"暂无内容"}},image:{type:String,default:""}},computed:{newImage:function(){return this.image?this.image:this.ipAddress+"/goods-imgae-no.png"}}};n.default=u}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/he-no-content-yet-create-component',
    {
        'components/he-no-content-yet-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("aa66"))
        })
    },
    [['components/he-no-content-yet-create-component']]
]);
