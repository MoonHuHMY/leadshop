(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-comments"],{"1f30":function(e,t,n){"use strict";n.r(t);var u=n("f44e"),r=n("be54");for(var f in r)["default"].indexOf(f)<0&&function(e){n.d(t,e,(function(){return r[e]}))}(f);n("69fd");var o,a=n("f0c5"),i=Object(a["a"])(r["default"],u["b"],u["c"],!1,null,"72eef054",null,!1,u["a"],o);t["default"]=i.exports},"69fd":function(e,t,n){"use strict";var u=n("9862"),r=n.n(u);r.a},9862:function(e,t,n){},be54:function(e,t,n){"use strict";n.r(t);var u=n("efb8"),r=n.n(u);for(var f in u)["default"].indexOf(f)<0&&function(e){n.d(t,e,(function(){return u[e]}))}(f);t["default"]=r.a},efb8:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n={name:"submit-comments",props:{note:String},methods:{navigateTo:function(){e.navigateTo({url:"/pages/other/buyer-message?note="+this.note})}}};t.default=n}).call(this,n("543d")["default"])},f44e:function(e,t,n){"use strict";var u;n.d(t,"b",(function(){return r})),n.d(t,"c",(function(){return f})),n.d(t,"a",(function(){return u}));var r=function(){var e=this,t=e.$createElement;e._self._c},f=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-comments-create-component',
    {
        'pages/order/components/submit-comments-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("1f30"))
        })
    },
    [['pages/order/components/submit-comments-create-component']]
]);
