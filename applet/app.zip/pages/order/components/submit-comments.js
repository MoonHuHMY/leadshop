(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-comments"],{"1f30":function(t,n,e){"use strict";e.r(n);var u=e("f44e"),a=e("be54");for(var r in a)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(r);e("69fd");var o,f=e("522a"),i=Object(f["a"])(a["default"],u["b"],u["c"],!1,null,"72eef054",null,!1,u["a"],o);n["default"]=i.exports},"69fd":function(t,n,e){"use strict";var u=e("f257"),a=e.n(u);a.a},be54:function(t,n,e){"use strict";e.r(n);var u=e("d29d"),a=e.n(u);for(var r in u)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(r);n["default"]=a.a},d29d:function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"submit-comments",props:{note:String},methods:{navigateTo:function(){t.navigateTo({url:"/pages/other/buyer-message?note="+this.note})}}};n.default=e}).call(this,e("35a2")["default"])},f257:function(t,n,e){},f44e:function(t,n,e){"use strict";var u;e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return u}));var a=function(){var t=this,n=t.$createElement;t._self._c},r=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-comments-create-component',
    {
        'pages/order/components/submit-comments-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("1f30"))
        })
    },
    [['pages/order/components/submit-comments-create-component']]
]);
