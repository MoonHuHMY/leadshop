(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-receipt"],{1643:function(n,t,e){"use strict";var r=e("5340"),a=e.n(r);a.a},5340:function(n,t,e){},6831:function(n,t,e){"use strict";e.r(t);var r=e("b006"),a=e.n(r);for(var u in r)["default"].indexOf(u)<0&&function(n){e.d(t,n,(function(){return r[n]}))}(u);t["default"]=a.a},"90aad":function(n,t,e){"use strict";var r;e.d(t,"b",(function(){return a})),e.d(t,"c",(function(){return u})),e.d(t,"a",(function(){return r}));var a=function(){var n=this,t=n.$createElement;n._self._c},u=[]},9160:function(n,t,e){"use strict";e.r(t);var r=e("90aad"),a=e("6831");for(var u in a)["default"].indexOf(u)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(u);e("1643");var i,c=e("8261"),o=Object(c["a"])(a["default"],r["b"],r["c"],!1,null,"98136094",null,!1,r["a"],i);t["default"]=o.exports},b006:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"detail-receipt",props:{consigneeInfo:{type:Object,default:function(){return{name:"",mobile:"",province:"",city:"",district:"",address:""}}}}};t.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-receipt-create-component',
    {
        'pages/order/components/detail-receipt-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('934e')['createComponent'](__webpack_require__("9160"))
        })
    },
    [['pages/order/components/detail-receipt-create-component']]
]);
