(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-product"],{"0f47":function(t,e,n){"use strict";var r=n("5b3e"),a=n.n(r);a.a},"5b3e":function(t,e,n){},a2cb:function(t,e,n){"use strict";n.r(e);var r=n("a3b2"),a=n("d336");for(var u in a)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(u);n("0f47");var i,o=n("8261"),f=Object(o["a"])(a["default"],r["b"],r["c"],!1,null,"3569e7ef",null,!1,r["a"],i);e["default"]=f.exports},a3b2:function(t,e,n){"use strict";var r;n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return r}));var a=function(){var t=this,e=t.$createElement,n=(t._self._c,t.__map(t.goodsData,(function(e,n){var r=t.__get_orig(e),a=t._f("getFail")(e.failure_reason,e.failure_number);return{$orig:r,f0:a}})));t.$mp.data=Object.assign({},{$root:{l0:n}})},u=[]},a784:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"submit-product",props:{goodsData:{type:Array,default:[]}},filters:{getFail:function(t,e){switch(t){case"limit":return"商品限购"+e+"件"}}}};e.default=r},d336:function(t,e,n){"use strict";n.r(e);var r=n("a784"),a=n.n(r);for(var u in r)["default"].indexOf(u)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(u);e["default"]=a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-product-create-component',
    {
        'pages/order/components/submit-product-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('934e')['createComponent'](__webpack_require__("a2cb"))
        })
    },
    [['pages/order/components/submit-product-create-component']]
]);
