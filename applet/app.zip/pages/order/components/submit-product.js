(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-product"],{"0f47":function(t,n,e){"use strict";var r=e("15da"),a=e.n(r);a.a},"15da":function(t,n,e){},a2cb:function(t,n,e){"use strict";e.r(n);var r=e("a3b2"),a=e("d336");for(var u in a)["default"].indexOf(u)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(u);e("0f47");var i,o=e("f0c5"),f=Object(o["a"])(a["default"],r["b"],r["c"],!1,null,"3569e7ef",null,!1,r["a"],i);n["default"]=f.exports},a3b2:function(t,n,e){"use strict";var r;e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return u})),e.d(n,"a",(function(){return r}));var a=function(){var t=this,n=t.$createElement,e=(t._self._c,t.__map(t.goodsData,(function(n,e){var r=t.__get_orig(n),a=t._f("getFail")(n.failure_reason,n.failure_number);return{$orig:r,f0:a}})));t.$mp.data=Object.assign({},{$root:{l0:e}})},u=[]},d336:function(t,n,e){"use strict";e.r(n);var r=e("d45d"),a=e.n(r);for(var u in r)["default"].indexOf(u)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(u);n["default"]=a.a},d45d:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={name:"submit-product",props:{goodsData:{type:Array,default:[]}},filters:{getFail:function(t,n){switch(t){case"limit":return"商品限购"+n+"件"}}}};n.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-product-create-component',
    {
        'pages/order/components/submit-product-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("a2cb"))
        })
    },
    [['pages/order/components/submit-product-create-component']]
]);
