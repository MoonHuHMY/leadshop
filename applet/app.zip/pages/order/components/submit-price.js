(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/submit-price"],{1698:function(t,e,n){"use strict";var r;n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return f})),n.d(e,"a",(function(){return r}));var u=function(){var t=this,e=t.$createElement,n=(t._self._c,t._f("floatPrice")(t.goodsAmount)),r=t._f("floatPrice")(t.freightAmount);t.$mp.data=Object.assign({},{$root:{f0:n,f1:r}})},f=[]},"66ae":function(t,e,n){},"98fd":function(t,e,n){"use strict";var r=n("66ae"),u=n.n(r);u.a},"9d77":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={name:"submit-price",props:{goodsAmount:{type:Number},freightAmount:{type:Number}}};e.default=r},ef31:function(t,e,n){"use strict";n.r(e);var r=n("9d77"),u=n.n(r);for(var f in r)["default"].indexOf(f)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(f);e["default"]=u.a},fd7a:function(t,e,n){"use strict";n.r(e);var r=n("1698"),u=n("ef31");for(var f in u)["default"].indexOf(f)<0&&function(t){n.d(e,t,(function(){return u[t]}))}(f);n("98fd");var a,o=n("8261"),i=Object(o["a"])(u["default"],r["b"],r["c"],!1,null,"fba7296a",null,!1,r["a"],a);e["default"]=i.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/submit-price-create-component',
    {
        'pages/order/components/submit-price-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('934e')['createComponent'](__webpack_require__("fd7a"))
        })
    },
    [['pages/order/components/submit-price-create-component']]
]);
