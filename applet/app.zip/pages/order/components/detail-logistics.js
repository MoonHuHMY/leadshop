(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/order/components/detail-logistics"],{"07e8":function(t,e,n){"use strict";n.r(e);var i=n("77d6"),r=n("b6cf");for(var o in r)["default"].indexOf(o)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(o);n("9c40");var u,a=n("8261"),c=Object(a["a"])(r["default"],i["b"],i["c"],!1,null,"4d743bb8",null,!1,i["a"],u);e["default"]=c.exports},"77d6":function(t,e,n){"use strict";var i;n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return o})),n.d(e,"a",(function(){return i}));var r=function(){var t=this,e=t.$createElement,n=(t._self._c,1===t.freight.type?t.$h.test.isEmpty(t.freightObj.status):null);t.$mp.data=Object.assign({},{$root:{g0:n}})},o=[]},"9c40":function(t,e,n){"use strict";var i=n("d577"),r=n.n(i);r.a},b6cf:function(t,e,n){"use strict";n.r(e);var i=n("d19b"),r=n.n(i);for(var o in i)["default"].indexOf(o)<0&&function(t){n.d(e,t,(function(){return i[t]}))}(o);e["default"]=r.a},d19b:function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={name:"detail-logistics",props:{freight:{type:Object,default:function(){return{}}},freightObj:{type:Object,default:function(){return{status:0}}},mobile:{type:String}},methods:{navigateTo:function(){t.navigateTo({url:"/pages/order/logistics?no="+this.freight.freight_sn+"&name="+this.freight.logistics_company+"&mobile="+this.mobile})},copy:function(t){this.uniCopy({content:t})}}};e.default=n}).call(this,n("934e")["default"])},d577:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/order/components/detail-logistics-create-component',
    {
        'pages/order/components/detail-logistics-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('934e')['createComponent'](__webpack_require__("07e8"))
        })
    },
    [['pages/order/components/detail-logistics-create-component']]
]);
