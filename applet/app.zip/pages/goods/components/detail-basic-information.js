(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-basic-information"],{"15c6":function(e,t,n){"use strict";var u;n.d(t,"b",(function(){return a})),n.d(t,"c",(function(){return r})),n.d(t,"a",(function(){return u}));var a=function(){var e=this,t=e.$createElement;e._self._c;e._isMounted||(e.e0=function(t){e.show=!0})},r=[]},"57a8":function(e,t,n){"use strict";var u=n("7068"),a=n.n(u);a.a},7068:function(e,t,n){},bde5:function(e,t,n){"use strict";n.r(t);var u=n("d0a4"),a=n.n(u);for(var r in u)["default"].indexOf(r)<0&&function(e){n.d(t,e,(function(){return u[e]}))}(r);t["default"]=a.a},d0a4:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u=function(){n.e("components/he-share").then(function(){return resolve(n("3f1e"))}.bind(null,n)).catch(n.oe)},a={name:"detail-basic-information",components:{heShare:u},props:{name:{type:String,default:""},price:{type:String,default:""},unit:{type:String,default:""},linePrice:{type:String,default:""},sales:{type:Number,default:0},virtual_sales:{type:Number,default:0},goodsId:{type:Number,default:function(){return 0}},goods:{type:Object}},data:function(){return{show:!1,list:[]}},methods:{}};t.default=a},ff37:function(e,t,n){"use strict";n.r(t);var u=n("15c6"),a=n("bde5");for(var r in a)["default"].indexOf(r)<0&&function(e){n.d(t,e,(function(){return a[e]}))}(r);n("57a8");var o,i=n("8261"),c=Object(i["a"])(a["default"],u["b"],u["c"],!1,null,"63de65c4",null,!1,u["a"],o);t["default"]=c.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-basic-information-create-component',
    {
        'pages/goods/components/detail-basic-information-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('934e')['createComponent'](__webpack_require__("ff37"))
        })
    },
    [['pages/goods/components/detail-basic-information-create-component']]
]);
