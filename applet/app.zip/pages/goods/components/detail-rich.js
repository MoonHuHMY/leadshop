(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-rich"],{"088c":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=function(){Promise.all([e.e("common/vendor"),e.e("components/he-html/he-html")]).then(function(){return resolve(e("7dc4"))}.bind(null,e)).catch(e.oe)},c={name:"detail-rich",props:{content:{type:[String,Array]}},components:{heRich:a}};t.default=c},"18b3":function(n,t,e){"use strict";e.r(t);var a=e("d3bb"),c=e("9aa4");for(var r in c)["default"].indexOf(r)<0&&function(n){e.d(t,n,(function(){return c[n]}))}(r);e("a5af");var o,u=e("f0c5"),i=Object(u["a"])(c["default"],a["b"],a["c"],!1,null,"7d4dce8d",null,!1,a["a"],o);t["default"]=i.exports},"98a4":function(n,t,e){},"9aa4":function(n,t,e){"use strict";e.r(t);var a=e("088c"),c=e.n(a);for(var r in a)["default"].indexOf(r)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(r);t["default"]=c.a},a5af:function(n,t,e){"use strict";var a=e("98a4"),c=e.n(a);c.a},d3bb:function(n,t,e){"use strict";var a;e.d(t,"b",(function(){return c})),e.d(t,"c",(function(){return r})),e.d(t,"a",(function(){return a}));var c=function(){var n=this,t=n.$createElement;n._self._c},r=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-rich-create-component',
    {
        'pages/goods/components/detail-rich-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("18b3"))
        })
    },
    [['pages/goods/components/detail-rich-create-component']]
]);
