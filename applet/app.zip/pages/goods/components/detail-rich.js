(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-rich"],{"18b3":function(n,t,e){"use strict";e.r(t);var c=e("4dcc"),r=e("9aa4");for(var a in r)["default"].indexOf(a)<0&&function(n){e.d(t,n,(function(){return r[n]}))}(a);e("ea27");var o,u=e("522a"),i=Object(u["a"])(r["default"],c["b"],c["c"],!1,null,"dc1363cc",null,!1,c["a"],o);t["default"]=i.exports},"4dcc":function(n,t,e){"use strict";var c;e.d(t,"b",(function(){return r})),e.d(t,"c",(function(){return a})),e.d(t,"a",(function(){return c}));var r=function(){var n=this,t=n.$createElement;n._self._c},a=[]},"9aa4":function(n,t,e){"use strict";e.r(t);var c=e("c286"),r=e.n(c);for(var a in c)["default"].indexOf(a)<0&&function(n){e.d(t,n,(function(){return c[n]}))}(a);t["default"]=r.a},c286:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var c=function(){Promise.all([e.e("common/vendor"),e.e("components/he-html/he-html")]).then(function(){return resolve(e("7dc4"))}.bind(null,e)).catch(e.oe)},r={name:"detail-rich",props:{content:{type:[String,Array]}},components:{heRich:c}};t.default=r},ea27:function(n,t,e){"use strict";var c=e("fc92"),r=e.n(c);r.a},fc92:function(n,t,e){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-rich-create-component',
    {
        'pages/goods/components/detail-rich-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("18b3"))
        })
    },
    [['pages/goods/components/detail-rich-create-component']]
]);
