(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-rich"],{"18b3":function(n,e,t){"use strict";t.r(e);var r=t("d3bb"),a=t("9aa4");for(var c in a)["default"].indexOf(c)<0&&function(n){t.d(e,n,(function(){return a[n]}))}(c);t("a5af");var o,u=t("8261"),i=Object(u["a"])(a["default"],r["b"],r["c"],!1,null,"7d4dce8d",null,!1,r["a"],o);e["default"]=i.exports},"5e72":function(n,e,t){},"9aa4":function(n,e,t){"use strict";t.r(e);var r=t("c725"),a=t.n(r);for(var c in r)["default"].indexOf(c)<0&&function(n){t.d(e,n,(function(){return r[n]}))}(c);e["default"]=a.a},a5af:function(n,e,t){"use strict";var r=t("5e72"),a=t.n(r);a.a},c725:function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r=function(){Promise.all([t.e("common/vendor"),t.e("components/he-html/he-html")]).then(function(){return resolve(t("7dc4"))}.bind(null,t)).catch(t.oe)},a={name:"detail-rich",props:{content:{type:[String,Array]}},components:{heRich:r}};e.default=a},d3bb:function(n,e,t){"use strict";var r;t.d(e,"b",(function(){return a})),t.d(e,"c",(function(){return c})),t.d(e,"a",(function(){return r}));var a=function(){var n=this,e=n.$createElement;n._self._c},c=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-rich-create-component',
    {
        'pages/goods/components/detail-rich-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('934e')['createComponent'](__webpack_require__("18b3"))
        })
    },
    [['pages/goods/components/detail-rich-create-component']]
]);
