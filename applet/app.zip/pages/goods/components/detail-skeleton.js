(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-skeleton"],{"0c28":function(n,t,e){"use strict";var u;e.d(t,"b",(function(){return f})),e.d(t,"c",(function(){return r})),e.d(t,"a",(function(){return u}));var f=function(){var n=this,t=n.$createElement;n._self._c},r=[]},"45b3":function(n,t,e){},bfeb:function(n,t,e){"use strict";e.r(t);var u=e("df0f"),f=e.n(u);for(var r in u)["default"].indexOf(r)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(r);t["default"]=f.a},c5f4:function(n,t,e){"use strict";e.r(t);var u=e("0c28"),f=e("bfeb");for(var r in f)["default"].indexOf(r)<0&&function(n){e.d(t,n,(function(){return f[n]}))}(r);e("f076");var a,c=e("8261"),o=Object(c["a"])(f["default"],u["b"],u["c"],!1,null,null,null,!1,u["a"],a);t["default"]=o.exports},df0f:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={name:"detail-skeleton"};t.default=u},f076:function(n,t,e){"use strict";var u=e("45b3"),f=e.n(u);f.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-skeleton-create-component',
    {
        'pages/goods/components/detail-skeleton-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('934e')['createComponent'](__webpack_require__("c5f4"))
        })
    },
    [['pages/goods/components/detail-skeleton-create-component']]
]);
