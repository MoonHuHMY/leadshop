(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-skeleton"],{"30ae":function(n,e,t){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={name:"detail-skeleton"};e.default=a},"913f":function(n,e,t){},aea2:function(n,e,t){"use strict";var a;t.d(e,"b",(function(){return u})),t.d(e,"c",(function(){return f})),t.d(e,"a",(function(){return a}));var u=function(){var n=this,e=n.$createElement;n._self._c},f=[]},bfeb:function(n,e,t){"use strict";t.r(e);var a=t("30ae"),u=t.n(a);for(var f in a)["default"].indexOf(f)<0&&function(n){t.d(e,n,(function(){return a[n]}))}(f);e["default"]=u.a},c5f4:function(n,e,t){"use strict";t.r(e);var a=t("aea2"),u=t("bfeb");for(var f in u)["default"].indexOf(f)<0&&function(n){t.d(e,n,(function(){return u[n]}))}(f);t("f076");var r,o=t("522a"),c=Object(o["a"])(u["default"],a["b"],a["c"],!1,null,null,null,!1,a["a"],r);e["default"]=c.exports},f076:function(n,e,t){"use strict";var a=t("913f"),u=t.n(a);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-skeleton-create-component',
    {
        'pages/goods/components/detail-skeleton-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("c5f4"))
        })
    },
    [['pages/goods/components/detail-skeleton-create-component']]
]);
