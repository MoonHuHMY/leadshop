(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/components/detail-args"],{"54a1":function(n,t,e){"use strict";var a;e.d(t,"b",(function(){return u})),e.d(t,"c",(function(){return o})),e.d(t,"a",(function(){return a}));var u=function(){var n=this,t=n.$createElement;n._self._c;n._isMounted||(n.e0=function(t){n.showModal=!1})},o=[]},"826a":function(n,t,e){"use strict";e.r(t);var a=e("54a1"),u=e("caae");for(var o in u)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(o);e("b6b5");var c,r=e("522a"),i=Object(r["a"])(u["default"],a["b"],a["c"],!1,null,"1ba84c24",null,!1,a["a"],c);t["default"]=i.exports},a503:function(n,t,e){},b1ca:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a=function(){e.e("components/he-popup").then(function(){return resolve(e("c2c4"))}.bind(null,e)).catch(e.oe)},u={name:"detail-args",components:{HePopup:a},props:{value:{type:Boolean},list:{type:Array}},computed:{showModal:{get:function(n){var t=n.value;return t},set:function(n){this.$emit("input",n)}}}};t.default=u},b6b5:function(n,t,e){"use strict";var a=e("a503"),u=e.n(a);u.a},caae:function(n,t,e){"use strict";e.r(t);var a=e("b1ca"),u=e.n(a);for(var o in a)["default"].indexOf(o)<0&&function(n){e.d(t,n,(function(){return a[n]}))}(o);t["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/components/detail-args-create-component',
    {
        'pages/goods/components/detail-args-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("826a"))
        })
    },
    [['pages/goods/components/detail-args-create-component']]
]);
