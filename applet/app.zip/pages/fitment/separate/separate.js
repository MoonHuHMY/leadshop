(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/fitment/separate/separate"],{"64f7":function(t,e,n){"use strict";n.r(e);var r=n("cbbc"),a=n.n(r);for(var c in r)["default"].indexOf(c)<0&&function(t){n.d(e,t,(function(){return r[t]}))}(c);e["default"]=a.a},9990:function(t,e,n){"use strict";n.r(e);var r=n("ec75"),a=n("64f7");for(var c in a)["default"].indexOf(c)<0&&function(t){n.d(e,t,(function(){return a[t]}))}(c);var u,f=n("522a"),i=Object(f["a"])(a["default"],r["b"],r["c"],!1,null,null,null,!1,r["a"],u);e["default"]=i.exports},cbbc:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={props:{facade:{type:[Object,Array]},content:{type:[Object,Array]}},computed:{margin:function(){return 1==this.facade.chamfer_style?0:10}}};e.default=r},ec75:function(t,e,n){"use strict";var r;n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return c})),n.d(e,"a",(function(){return r}));var a=function(){var t=this,e=t.$createElement;t._self._c},c=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/fitment/separate/separate-create-component',
    {
        'pages/fitment/separate/separate-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("9990"))
        })
    },
    [['pages/fitment/separate/separate-create-component']]
]);
