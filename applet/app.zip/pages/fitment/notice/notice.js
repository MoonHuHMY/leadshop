(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/fitment/notice/notice"],{"05a7":function(t,n,e){"use strict";e.r(n);var c=e("e258"),r=e("d8ae");for(var u in r)["default"].indexOf(u)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(u);e("53d6");var a,i=e("f0c5"),o=Object(i["a"])(r["default"],c["b"],c["c"],!1,null,"5285b710",null,!1,c["a"],a);n["default"]=o.exports},"3c70":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var c=function(){e.e("pages/fitment/notice/item").then(function(){return resolve(e("5f35"))}.bind(null,e)).catch(e.oe)},r={components:{item:c},props:{facade:{type:[Object,Array]},content:{type:[Object,Array]}},name:"notice"};n.default=r},"53d6":function(t,n,e){"use strict";var c=e("d908"),r=e.n(c);r.a},d8ae:function(t,n,e){"use strict";e.r(n);var c=e("3c70"),r=e.n(c);for(var u in c)["default"].indexOf(u)<0&&function(t){e.d(n,t,(function(){return c[t]}))}(u);n["default"]=r.a},d908:function(t,n,e){},e258:function(t,n,e){"use strict";var c;e.d(n,"b",(function(){return r})),e.d(n,"c",(function(){return u})),e.d(n,"a",(function(){return c}));var r=function(){var t=this,n=t.$createElement;t._self._c},u=[]}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/fitment/notice/notice-create-component',
    {
        'pages/fitment/notice/notice-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("05a7"))
        })
    },
    [['pages/fitment/notice/notice-create-component']]
]);
