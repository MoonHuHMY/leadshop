(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/fitment/notice/notice"],{"05a7":function(t,n,e){"use strict";e.r(n);var a=e("1920"),c=e("d8ae");for(var r in c)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return c[t]}))}(r);e("ad47");var u,i=e("522a"),f=Object(i["a"])(c["default"],a["b"],a["c"],!1,null,"5308fe6b",null,!1,a["a"],u);n["default"]=f.exports},1920:function(t,n,e){"use strict";var a;e.d(n,"b",(function(){return c})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return a}));var c=function(){var t=this,n=t.$createElement;t._self._c},r=[]},"520b":function(t,n,e){},"73fc":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a=function(){e.e("pages/fitment/notice/item").then(function(){return resolve(e("5f35"))}.bind(null,e)).catch(e.oe)},c={components:{item:a},props:{facade:{type:[Object,Array]},content:{type:[Object,Array]}},name:"notice"};n.default=c},ad47:function(t,n,e){"use strict";var a=e("520b"),c=e.n(a);c.a},d8ae:function(t,n,e){"use strict";e.r(n);var a=e("73fc"),c=e.n(a);for(var r in a)["default"].indexOf(r)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(r);n["default"]=c.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/fitment/notice/notice-create-component',
    {
        'pages/fitment/notice/notice-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('35a2')['createComponent'](__webpack_require__("05a7"))
        })
    },
    [['pages/fitment/notice/notice-create-component']]
]);
